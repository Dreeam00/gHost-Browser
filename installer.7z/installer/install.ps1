Add-Type -AssemblyName System.Windows.Forms

# --- 前提条件 ---
$global:needsDotNetInstall = $false
try {
    $sdkList = (dotnet --list-sdks) 2>$null
    if (($LASTEXITCODE -ne 0) -or -not ($sdkList -match "^9\.")) {
        $global:needsDotNetInstall = $true
    }
} catch {
    $global:needsDotNetInstall = $true
}

$regPath1 = "HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
$regPath2 = "HKLM:\\SOFTWARE\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
$global:needsWebView2Install = -not ((Test-Path $regPath1) -or (Test-Path $regPath2))

# --- 共通色・フォント ---
$mainColor = [System.Drawing.Color]::FromArgb(40, 80, 160)
$accentColor = [System.Drawing.Color]::FromArgb(80, 160, 220)
$fontTitle = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$fontStep = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)

# --- メインフォーム ---
$form = New-Object System.Windows.Forms.Form
$form.Text = "IFoxer セットアップ"
$form.Size = New-Object System.Drawing.Size(600, 420)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::White

# --- ステップインジケーター ---
$lblStep = New-Object System.Windows.Forms.Label
$lblStep.Location = New-Object System.Drawing.Point(20, 10)
$lblStep.Size = New-Object System.Drawing.Size(120, 30)
$lblStep.Font = $fontStep
$form.Controls.Add($lblStep)

# --- パネル定義 ---
$panels = @{}
foreach ($name in 'Welcome','Prerequisites','License','Folder','Confirm','Progress','Finish') {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.BackColor = [System.Drawing.Color]::White
    $panels[$name] = $p
}

function Show-Step($step, $panel) {
    $maxSteps = 6
    if ($global:needsDotNetInstall -or $global:needsWebView2Install) { $maxSteps = 7 }
    $lblStep.Text = "Step $step/$maxSteps"
    $form.Controls.Clear()
    $form.Controls.Add($lblStep)
    $form.Controls.Add($panel)
}

# --- Welcome ---
$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "IFoxer セットアップへようこそ"
$lblTitle.Font = $fontTitle

$lblTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Welcome'].Controls.Add($lblTitle)

$lblDesc = New-Object System.Windows.Forms.Label
$lblDesc.Text = "このウィザードはIFoxerのインストールをガイドします。"
$lblDesc.Location = New-Object System.Drawing.Point(40, 120)
$lblDesc.Size = New-Object System.Drawing.Size(500, 30)
$panels['Welcome'].Controls.Add($lblDesc)

$btnWelcomeNext = New-Object System.Windows.Forms.Button
$btnWelcomeNext.Text = "次へ"
$btnWelcomeNext.Location = New-Object System.Drawing.Point(450, 320)
$btnWelcomeNext.Size = New-Object System.Drawing.Size(100, 36)
$btnWelcomeNext.BackColor = $mainColor
$btnWelcomeNext.ForeColor = [System.Drawing.Color]::White
$btnWelcomeNext.FlatStyle = 'Flat'
$btnWelcomeNext.Add_Click({ 
    if ($global:needsDotNetInstall -or $global:needsWebView2Install) {
        $chkInstallDotNet.Visible = $global:needsDotNetInstall
        $chkInstallWebView2.Visible = $global:needsWebView2Install
        Show-Step 2 $panels['Prerequisites'] 
    } else {
        Show-Step 2 $panels['License']
    }
})
$panels['Welcome'].Controls.Add($btnWelcomeNext)

# --- Prerequisites ---
$lblPrereqTitle = New-Object System.Windows.Forms.Label
$lblPrereqTitle.Text = "前提条件"
$lblPrereqTitle.Font = $fontTitle
$lblPrereqTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblPrereqTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Prerequisites'].Controls.Add($lblPrereqTitle)

$chkInstallDotNet = New-Object System.Windows.Forms.CheckBox
$chkInstallDotNet.Text = ".NET 9.0 SDK が見つかりません。インストールしますか？"
$chkInstallDotNet.Location = New-Object System.Drawing.Point(40, 120)
$chkInstallDotNet.Size = New-Object System.Drawing.Size(500, 30)
$chkInstallDotNet.Checked = $true
$panels['Prerequisites'].Controls.Add($chkInstallDotNet)

$chkInstallWebView2 = New-Object System.Windows.Forms.CheckBox
$chkInstallWebView2.Text = "WebView2 Runtime が見つかりません。インストールしますか？"
$chkInstallWebView2.Location = New-Object System.Drawing.Point(40, 160)
$chkInstallWebView2.Size = New-Object System.Drawing.Size(500, 30)
$chkInstallWebView2.Checked = $true
$panels['Prerequisites'].Controls.Add($chkInstallWebView2)

$btnPrereqNext = New-Object System.Windows.Forms.Button
$btnPrereqNext.Text = "次へ"
$btnPrereqNext.Location = New-Object System.Drawing.Point(450, 320)
$btnPrereqNext.Size = New-Object System.Drawing.Size(100, 36)
$btnPrereqNext.BackColor = $mainColor
$btnPrereqNext.ForeColor = [System.Drawing.Color]::White
$btnPrereqNext.FlatStyle = 'Flat'
$btnPrereqNext.Add_Click({ Show-Step 3 $panels['License'] })
$panels['Prerequisites'].Controls.Add($btnPrereqNext)

# --- License ---
$lblLicenseTitle = New-Object System.Windows.Forms.Label
$lblLicenseTitle.Text = "利用規約"
$lblLicenseTitle.Font = $fontTitle
$lblLicenseTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblLicenseTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['License'].Controls.Add($lblLicenseTitle)

$txtLicense = New-Object System.Windows.Forms.TextBox
$txtLicense.Multiline = $true
$txtLicense.ReadOnly = $true
$txtLicense.Text = "本ソフトウェアはMITライセンスです。\r\n自己責任でご利用ください。"
$txtLicense.Location = New-Object System.Drawing.Point(40, 120)
$txtLicense.Size = New-Object System.Drawing.Size(500, 120)
$panels['License'].Controls.Add($txtLicense)

$btnLicenseAgree = New-Object System.Windows.Forms.Button
$btnLicenseAgree.Text = "同意する"
$btnLicenseAgree.Location = New-Object System.Drawing.Point(450, 320)
$btnLicenseAgree.Size = New-Object System.Drawing.Size(100, 36)
$btnLicenseAgree.BackColor = $mainColor
$btnLicenseAgree.ForeColor = [System.Drawing.Color]::White
$btnLicenseAgree.FlatStyle = 'Flat'
$btnLicenseAgree.Add_Click({ 
    if ($global:needsDotNetInstall -or $global:needsWebView2Install) {
        Show-Step 4 $panels['Folder'] 
    } else {
        Show-Step 3 $panels['Folder']
    }
})
$panels['License'].Controls.Add($btnLicenseAgree)

# --- Folder ---
$lblFolderTitle = New-Object System.Windows.Forms.Label
$lblFolderTitle.Text = "インストール先フォルダを選択してください:"
$lblFolderTitle.Font = $fontTitle
$lblFolderTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblFolderTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Folder'].Controls.Add($lblFolderTitle)
$txtFolder = New-Object System.Windows.Forms.TextBox
$txtFolder.Location = New-Object System.Drawing.Point(40, 120)
$txtFolder.Size = New-Object System.Drawing.Size(340,28)
$panels['Folder'].Controls.Add($txtFolder)
$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "参照..."
$btnBrowse.Location = New-Object System.Drawing.Point(400,120)
$btnBrowse.Size = New-Object System.Drawing.Size(100,28)
$btnBrowse.BackColor = $accentColor
$btnBrowse.ForeColor = [System.Drawing.Color]::White
$btnBrowse.FlatStyle = 'Flat'
$btnBrowse.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($fbd.ShowDialog() -eq 'OK') { $txtFolder.Text = $fbd.SelectedPath }
})
$panels['Folder'].Controls.Add($btnBrowse)
$lblFolderError = New-Object System.Windows.Forms.Label
$lblFolderError.ForeColor = 'Red'
$lblFolderError.Location = New-Object System.Drawing.Point(40,160)
$lblFolderError.Size = New-Object System.Drawing.Size(500,24)
$panels['Folder'].Controls.Add($lblFolderError)
$btnFolderNext = New-Object System.Windows.Forms.Button
$btnFolderNext.Text = "次へ"
$btnFolderNext.Location = New-Object System.Drawing.Point(450, 320)
$btnFolderNext.Size = New-Object System.Drawing.Size(100,36)
$btnFolderNext.BackColor = $mainColor
$btnFolderNext.ForeColor = [System.Drawing.Color]::White
$btnFolderNext.FlatStyle = 'Flat'
$btnFolderNext.Add_Click({
    $lblFolderError.Text = ""
    $installRoot = $txtFolder.Text
    if (-not (Test-Path $installRoot)) {
        $lblFolderError.Text = "有効なフォルダを選択してください。"
        return
    }
    $global:projDir = Join-Path $installRoot "IFoxer\IFoxer"
    $global:binDir = Join-Path $installRoot "bin\Debug\net9.0-windows"
    New-Item -ItemType Directory -Path $global:projDir -Force | Out-Null
    New-Item -ItemType Directory -Path $global:binDir -Force | Out-Null
    # 確認画面に内容を反映
    $txtConfirm.Text = "インストール先: $installRoot`r`n`r`nコピーされるファイル:`r`n" + (
        "BookmarkForm.cs, BookmarkListForm.cs, Form1.cs, Form1.Designer.cs, Form1.resx, IFoxer.csproj, IFoxer.csproj.user, IFoxer.sln, Program.cs, Settings.cs, SettingsForm.cs, IFoxer-Photoroom.png, index.html")
    
    $nextStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 5 } else { 4 }
    Show-Step $nextStep $panels['Confirm']
})
$panels['Folder'].Controls.Add($btnFolderNext)

# --- Confirm ---
$lblConfirmTitle = New-Object System.Windows.Forms.Label
$lblConfirmTitle.Text = "インストール内容の確認"
$lblConfirmTitle.Font = $fontTitle
$lblConfirmTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblConfirmTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Confirm'].Controls.Add($lblConfirmTitle)
$txtConfirm = New-Object System.Windows.Forms.TextBox
$txtConfirm.Multiline = $true
$txtConfirm.ReadOnly = $true
$txtConfirm.Location = New-Object System.Drawing.Point(40, 120)
$txtConfirm.Size = New-Object System.Drawing.Size(500, 120)
$panels['Confirm'].Controls.Add($txtConfirm)
$btnConfirmBack = New-Object System.Windows.Forms.Button
$btnConfirmBack.Text = "戻る"
$btnConfirmBack.Location = New-Object System.Drawing.Point(340, 320)
$btnConfirmBack.Size = New-Object System.Drawing.Size(100,36)
$btnConfirmBack.BackColor = $accentColor
$btnConfirmBack.ForeColor = [System.Drawing.Color]::White
$btnConfirmBack.FlatStyle = 'Flat'
$btnConfirmBack.Add_Click({ 
    $prevStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 4 } else { 3 }
    Show-Step $prevStep $panels['Folder'] 
})
$panels['Confirm'].Controls.Add($btnConfirmBack)
$btnConfirmInstall = New-Object System.Windows.Forms.Button
$btnConfirmInstall.Text = "インストール"
$btnConfirmInstall.Location = New-Object System.Drawing.Point(450, 320)
$btnConfirmInstall.Size = New-Object System.Drawing.Size(100,36)
$btnConfirmInstall.BackColor = $mainColor
$btnConfirmInstall.ForeColor = [System.Drawing.Color]::White
$btnConfirmInstall.FlatStyle = 'Flat'
$btnConfirmInstall.Add_Click({
    $nextStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 6 } else { 5 }
    Show-Step $nextStep $panels['Progress']
    $form.Refresh()
    
    function Update-Progress($value, $detail) {
        $progressBar.Value = [Math]::Min($value, 100)
        $lblProgDetail.Text = $detail
        $form.Refresh()
        Start-Sleep -Milliseconds 300
    }

    Update-Progress 0 "インストールの準備をしています..."
    Start-Sleep -Seconds 1

    # 0. .NET 9.0 SDKのインストール
    if ($global:needsDotNetInstall -and $chkInstallDotNet.Checked) {
        Update-Progress 5 ".NET 9.0 SDKのインストーラーをダウンロード中..."
        $dotNetInstaller = Join-Path $PSScriptRoot "dotnet-sdk-9-win-x64.exe"
        try {
            Invoke-WebRequest -Uri "https://aka.ms/dotnet/9.0/windowsdesktop-runtime-win-x64.exe" -OutFile $dotNetInstaller
            Update-Progress 10 ".NET 9.0 SDKのダウンロードが完了しました。"
            Start-Sleep -Seconds 1
            Update-Progress 15 ".NET 9.0 SDKをインストール中... (完了まで数分かかる場合があります)"
            Start-Process -FilePath $dotNetInstaller -ArgumentList "/install /quiet /norestart" -Wait
            Update-Progress 20 ".NET 9.0 SDKのインストールが完了しました。"
        } catch {
            Update-Progress 0 ".NET 9.0 SDKのインストールに失敗しました。"
            return
        }
    }

    Update-Progress 25 "ソースファイルのコピー準備をしています..."
    Start-Sleep -Seconds 1
    
    # 1. IFoxer/IFoxer/にソースコピー
    $filesSrc = @(
        "BookmarkForm.cs","BookmarkListForm.cs","Form1.cs","Form1.Designer.cs","Form1.resx",
        "IFoxer.csproj","IFoxer.csproj.user","IFoxer.sln","Program.cs","Settings.cs","SettingsForm.cs"
    )
    $src = $PSScriptRoot
    $currentStep = 25
    $stepIncrement = 15 / $filesSrc.Count
    foreach ($f in $filesSrc) {
        Copy-Item -Path (Join-Path $src $f) -Destination $global:projDir -Force -ErrorAction Stop
        $currentStep += $stepIncrement
        Update-Progress $currentStep "コピー中: $f"
        Start-Sleep -Milliseconds 500
    }
    Update-Progress 40 "ソースファイルのコピーが完了しました。"
    Start-Sleep -Seconds 1
    
    # 2. ビルド
    Update-Progress 45 "アプリケーションのビルド準備をしています..."
    Start-Sleep -Seconds 1
    Update-Progress 50 "ビルドを実行中... しばらくお待ちください。"
    $buildResult = & dotnet build (Join-Path $global:projDir "IFoxer.csproj") -c Debug
    if ($LASTEXITCODE -ne 0) {
        Update-Progress 45 "ビルドに失敗しました。ログを確認してください。"
        return
    }
    Update-Progress 70 "ビルドが正常に完了しました。"
    Start-Sleep -Seconds 1

    # 3. bin/Debug/net9.0-windows/にリソース・成果物コピー
    Update-Progress 75 "成果物ファイルのコピー準備をしています..."
    $binSrc = Join-Path $global:projDir "bin/Debug/net9.0-windows"
    $binDst = $global:binDir
    $binFiles = @("IFoxer-Photoroom.png","index.html")
    foreach ($f in $binFiles) {
        Copy-Item -Path (Join-Path $src $f) -Destination $binDst -Force -ErrorAction Stop
        Update-Progress $progressBar.Value "リソースをコピー中: $f"
        Start-Sleep -Milliseconds 500
    }
    
    $buildOutFiles = Get-ChildItem -Path $binSrc -File
    $currentStep = 75
    $stepIncrement = 15 / $buildOutFiles.Count
    foreach ($f in $buildOutFiles) {
        Copy-Item $f.FullName -Destination $binDst -Force
        $currentStep += $stepIncrement
        Update-Progress $currentStep "ビルド成果物をコピー中: $($f.Name)"
        Start-Sleep -Milliseconds 200
    }
    Update-Progress 90 "成果物ファイルのコピーが完了しました。"
    Start-Sleep -Seconds 1

    # WebView2
    if ($global:needsWebView2Install -and $chkInstallWebView2.Checked) {
        Update-Progress 92 "WebView2 ランタイムを準備中..."
        $wv2Installer = Join-Path $PSScriptRoot "MicrosoftEdgeWebView2Setup.exe"
        try {
            if (!(Test-Path $wv2Installer)) {
                Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?LinkId=2124703" -OutFile $wv2Installer
            }
            Update-Progress 95 "WebView2 ランタイムをインストール中..."
            Start-Process -FilePath $wv2Installer -ArgumentList "/silent /install" -Wait
        } catch {
            Update-Progress 90 "WebView2 ランタイムのインストールに失敗しました。"
            Start-Sleep -Seconds 2
        }
    }
    
    Update-Progress 100 "最終処理中..."
    Start-Sleep -Seconds 2
    Update-Progress 100 "インストール完了！"
    Start-Sleep -Milliseconds 500
    $finalStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 7 } else { 6 }
    Show-Step $finalStep $panels['Finish']
})
$panels['Confirm'].Controls.Add($btnConfirmInstall)

# --- Progress ---
$lblProg = New-Object System.Windows.Forms.Label
$lblProg.Text = "インストール中..."
$lblProg.Font = $fontTitle
$lblProg.Location = New-Object System.Drawing.Point(40, 60)
$lblProg.Size = New-Object System.Drawing.Size(500, 40)
$panels['Progress'].Controls.Add($lblProg)
$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Location = New-Object System.Drawing.Point(40, 120)
$progressBar.Size = New-Object System.Drawing.Size(500, 28)
$progressBar.Minimum = 0
$progressBar.Maximum = 100
$panels['Progress'].Controls.Add($progressBar)
$lblProgDetail = New-Object System.Windows.Forms.Label
$lblProgDetail.Text = ""
$lblProgDetail.Location = New-Object System.Drawing.Point(40, 170)
$lblProgDetail.Size = New-Object System.Drawing.Size(500, 30)
$panels['Progress'].Controls.Add($lblProgDetail)

# --- Finish ---
$lblFinish = New-Object System.Windows.Forms.Label
$lblFinish.Text = "インストールが完了しました！"
$lblFinish.Font = $fontTitle
$lblFinish.Location = New-Object System.Drawing.Point(40, 60)
$lblFinish.Size = New-Object System.Drawing.Size(500, 40)
$panels['Finish'].Controls.Add($lblFinish)

$chkDeleteInstaller = New-Object System.Windows.Forms.CheckBox
$chkDeleteInstaller.Text = "インストーラーフォルダ（このフォルダ）を削除しますか？"
$chkDeleteInstaller.Location = New-Object System.Drawing.Point(40, 120)
$chkDeleteInstaller.Size = New-Object System.Drawing.Size(400, 30)
$chkDeleteInstaller.Checked = $true
$panels['Finish'].Controls.Add($chkDeleteInstaller)

$btnFinishClose = New-Object System.Windows.Forms.Button
$btnFinishClose.Text = "閉じる"
$btnFinishClose.Location = New-Object System.Drawing.Point(450, 320)
$btnFinishClose.Size = New-Object System.Drawing.Size(100,36)
$btnFinishClose.BackColor = $mainColor
$btnFinishClose.ForeColor = [System.Drawing.Color]::White
$btnFinishClose.FlatStyle = 'Flat'
$btnFinishClose.Add_Click({
    if ($chkDeleteInstaller.Checked) {
        try {
            Remove-Item -Path $PSScriptRoot -Recurse -Force
        } catch {
            [System.Windows.Forms.MessageBox]::Show("インストーラーフォルダの削除に失敗しました。手動で削除してください。", "削除失敗", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        }
    }
    $form.Close()
})
$panels['Finish'].Controls.Add($btnFinishClose)

# --- 最初の画面を表示 ---
Show-Step 1 $panels['Welcome']
$form.ShowDialog()