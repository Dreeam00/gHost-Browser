Add-Type -AssemblyName System.Windows.Forms

# --- 前提条件 ---
$global:needsDotNetInstall = $false
try {
    $sdkList = (dotnet --list-sdks) 2>$null
    if (($LASTEXITCODE -ne 0) -or -not ($sdkList -match "^9\.")) {
        $global:needsDotNetInstall = $true
    }
} catch {
    $global:needsDotNetInstall = $true
}

$regPath1 = "HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
$regPath2 = "HKLM:\\SOFTWARE\\Microsoft\\EdgeUpdate\\Clients\\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}"
$global:needsWebView2Install = -not ((Test-Path $regPath1) -or (Test-Path $regPath2))

# --- 共通色・フォント ---
$mainColor = [System.Drawing.Color]::FromArgb(40, 80, 160)
$accentColor = [System.Drawing.Color]::FromArgb(80, 160, 220)
$fontTitle = New-Object System.Drawing.Font("Segoe UI", 18, [System.Drawing.FontStyle]::Bold)
$fontStep = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Regular)

# --- メインフォーム ---
$form = New-Object System.Windows.Forms.Form
$form.Text = "IFoxer setup"
$form.Size = New-Object System.Drawing.Size(600, 420)
$form.StartPosition = "CenterScreen"
$form.BackColor = [System.Drawing.Color]::White

# --- ステップインジケーター ---
$lblStep = New-Object System.Windows.Forms.Label
$lblStep.Location = New-Object System.Drawing.Point(20, 10)
$lblStep.Size = New-Object System.Drawing.Size(120, 30)
$lblStep.Font = $fontStep
$form.Controls.Add($lblStep)

# --- パネル定義 ---
$panels = @{}
foreach ($name in 'Welcome','Prerequisites','License','Folder','Confirm','Progress','Finish') {
    $p = New-Object System.Windows.Forms.Panel
    $p.Dock = 'Fill'
    $p.BackColor = [System.Drawing.Color]::White
    $panels[$name] = $p
}

function Show-Step($step, $panel) {
    $maxSteps = 6
    if ($global:needsDotNetInstall -or $global:needsWebView2Install) { $maxSteps = 7 }
    $lblStep.Text = "Step $step/$maxSteps"
    $form.Controls.Clear()
    $form.Controls.Add($lblStep)
    $form.Controls.Add($panel)
}

# --- Welcome ---
$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "Welcome to the iFoxer setup"
$lblTitle.Font = $fontTitle

$lblTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Welcome'].Controls.Add($lblTitle)

$lblDesc = New-Object System.Windows.Forms.Label
$lblDesc.Text = "This wizard guides you through the installation of iFoxer."
$lblDesc.Location = New-Object System.Drawing.Point(40, 120)
$lblDesc.Size = New-Object System.Drawing.Size(500, 30)
$panels['Welcome'].Controls.Add($lblDesc)

$btnWelcomeNext = New-Object System.Windows.Forms.Button
$btnWelcomeNext.Text = "Next"
$btnWelcomeNext.Location = New-Object System.Drawing.Point(450, 320)
$btnWelcomeNext.Size = New-Object System.Drawing.Size(100, 36)
$btnWelcomeNext.BackColor = $mainColor
$btnWelcomeNext.ForeColor = [System.Drawing.Color]::White
$btnWelcomeNext.FlatStyle = 'Flat'
$btnWelcomeNext.Add_Click({ 
    if ($global:needsDotNetInstall -or $global:needsWebView2Install) {
        $chkInstallDotNet.Visible = $global:needsDotNetInstall
        $chkInstallWebView2.Visible = $global:needsWebView2Install
        Show-Step 2 $panels['Prerequisites'] 
    } else {
        Show-Step 2 $panels['License']
    }
})
$panels['Welcome'].Controls.Add($btnWelcomeNext)

# --- Prerequisites ---
$lblPrereqTitle = New-Object System.Windows.Forms.Label
$lblPrereqTitle.Text = "Prerequisite"
$lblPrereqTitle.Font = $fontTitle
$lblPrereqTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblPrereqTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Prerequisites'].Controls.Add($lblPrereqTitle)

$chkInstallDotNet = New-Object System.Windows.Forms.CheckBox
$chkInstallDotNet.Text = ".NET 9.0 SDK was not found. Do you want to install it?"
$chkInstallDotNet.Location = New-Object System.Drawing.Point(40, 120)
$chkInstallDotNet.Size = New-Object System.Drawing.Size(500, 30)
$chkInstallDotNet.Checked = $true
$panels['Prerequisites'].Controls.Add($chkInstallDotNet)

$chkInstallWebView2 = New-Object System.Windows.Forms.CheckBox
$chkInstallWebView2.Text = "WebView2 Runtime not found. Would you like to install it?"
$chkInstallWebView2.Location = New-Object System.Drawing.Point(40, 160)
$chkInstallWebView2.Size = New-Object System.Drawing.Size(500, 30)
$chkInstallWebView2.Checked = $true
$panels['Prerequisites'].Controls.Add($chkInstallWebView2)

$btnPrereqNext = New-Object System.Windows.Forms.Button
$btnPrereqNext.Text = "Next"
$btnPrereqNext.Location = New-Object System.Drawing.Point(450, 320)
$btnPrereqNext.Size = New-Object System.Drawing.Size(100, 36)
$btnPrereqNext.BackColor = $mainColor
$btnPrereqNext.ForeColor = [System.Drawing.Color]::White
$btnPrereqNext.FlatStyle = 'Flat'
$btnPrereqNext.Add_Click({ Show-Step 3 $panels['License'] })
$panels['Prerequisites'].Controls.Add($btnPrereqNext)

# --- License ---
$lblLicenseTitle = New-Object System.Windows.Forms.Label
$lblLicenseTitle.Text = "Terms of Service"
$lblLicenseTitle.Font = $fontTitle
$lblLicenseTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblLicenseTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['License'].Controls.Add($lblLicenseTitle)

$txtLicense = New-Object System.Windows.Forms.TextBox
$txtLicense.Multiline = $true
$txtLicense.ReadOnly = $true
$txtLicense.Text = "This software is open-source software. \r\nPlease use it at your own risk."
$txtLicense.Location = New-Object System.Drawing.Point(40, 120)
$txtLicense.Size = New-Object System.Drawing.Size(500, 120)
$panels['License'].Controls.Add($txtLicense)

$btnLicenseAgree = New-Object System.Windows.Forms.Button
$btnLicenseAgree.Text = "I agree."
$btnLicenseAgree.Location = New-Object System.Drawing.Point(450, 320)
$btnLicenseAgree.Size = New-Object System.Drawing.Size(100, 36)
$btnLicenseAgree.BackColor = $mainColor
$btnLicenseAgree.ForeColor = [System.Drawing.Color]::White
$btnLicenseAgree.FlatStyle = 'Flat'
$btnLicenseAgree.Add_Click({ 
    if ($global:needsDotNetInstall -or $global:needsWebView2Install) {
        Show-Step 4 $panels['Folder'] 
    } else {
        Show-Step 3 $panels['Folder']
    }
})
$panels['License'].Controls.Add($btnLicenseAgree)

# --- Folder ---
$lblFolderTitle = New-Object System.Windows.Forms.Label
$lblFolderTitle.Text = "Please select the installation folder:"
$lblFolderTitle.Font = $fontTitle
$lblFolderTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblFolderTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Folder'].Controls.Add($lblFolderTitle)
$txtFolder = New-Object System.Windows.Forms.TextBox
$txtFolder.Location = New-Object System.Drawing.Point(40, 120)
$txtFolder.Size = New-Object System.Drawing.Size(340,28)
$panels['Folder'].Controls.Add($txtFolder)
$btnBrowse = New-Object System.Windows.Forms.Button
$btnBrowse.Text = "Refer to..."
$btnBrowse.Location = New-Object System.Drawing.Point(400,120)
$btnBrowse.Size = New-Object System.Drawing.Size(100,28)
$btnBrowse.BackColor = $accentColor
$btnBrowse.ForeColor = [System.Drawing.Color]::White
$btnBrowse.FlatStyle = 'Flat'
$btnBrowse.Add_Click({
    $fbd = New-Object System.Windows.Forms.FolderBrowserDialog
    if ($fbd.ShowDialog() -eq 'OK') { $txtFolder.Text = $fbd.SelectedPath }
})
$panels['Folder'].Controls.Add($btnBrowse)
$lblFolderError = New-Object System.Windows.Forms.Label
$lblFolderError.ForeColor = 'Red'
$lblFolderError.Location = New-Object System.Drawing.Point(40,160)
$lblFolderError.Size = New-Object System.Drawing.Size(500,24)
$panels['Folder'].Controls.Add($lblFolderError)
$btnFolderNext = New-Object System.Windows.Forms.Button
$btnFolderNext.Text = "Next"
$btnFolderNext.Location = New-Object System.Drawing.Point(450, 320)
$btnFolderNext.Size = New-Object System.Drawing.Size(100,36)
$btnFolderNext.BackColor = $mainColor
$btnFolderNext.ForeColor = [System.Drawing.Color]::White
$btnFolderNext.FlatStyle = 'Flat'
$btnFolderNext.Add_Click({
    $lblFolderError.Text = ""
    $installRoot = $txtFolder.Text
    if (-not (Test-Path $installRoot)) {
        $lblFolderError.Text = "Please select a valid folder."
        return
    }
    $global:projDir = Join-Path $installRoot "IFoxer\IFoxer"
    $global:binDir = Join-Path $installRoot "bin\Debug\net9.0-windows"
    New-Item -ItemType Directory -Path $global:projDir -Force | Out-Null
    New-Item -ItemType Directory -Path $global:binDir -Force | Out-Null
    # 確認画面に内容を反映
    $txtConfirm.Text = "Installation destination: $installRoot`r`n`r`nFiles to be copied:`r`n" + (
        "BookmarkForm.cs, BookmarkListForm.cs, Form1.cs, Form1.Designer.cs, Form1.resx, IFoxer.csproj, IFoxer.csproj.user, IFoxer.sln, Program.cs, Settings.cs, SettingsForm.cs, IFoxer-Photoroom.png, index.html")
    
    $nextStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 5 } else { 4 }
    Show-Step $nextStep $panels['Confirm']
})
$panels['Folder'].Controls.Add($btnFolderNext)

# --- Confirm ---
$lblConfirmTitle = New-Object System.Windows.Forms.Label
$lblConfirmTitle.Text = "Confirmation of installation contents"
$lblConfirmTitle.Font = $fontTitle
$lblConfirmTitle.Location = New-Object System.Drawing.Point(40, 60)
$lblConfirmTitle.Size = New-Object System.Drawing.Size(500, 40)
$panels['Confirm'].Controls.Add($lblConfirmTitle)
$txtConfirm = New-Object System.Windows.Forms.TextBox
$txtConfirm.Multiline = $true
$txtConfirm.ReadOnly = $true
$txtConfirm.Location = New-Object System.Drawing.Point(40, 120)
$txtConfirm.Size = New-Object System.Drawing.Size(500, 120)
$panels['Confirm'].Controls.Add($txtConfirm)
$btnConfirmBack = New-Object System.Windows.Forms.Button
$btnConfirmBack.Text = "Back"
$btnConfirmBack.Location = New-Object System.Drawing.Point(340, 320)
$btnConfirmBack.Size = New-Object System.Drawing.Size(100,36)
$btnConfirmBack.BackColor = $accentColor
$btnConfirmBack.ForeColor = [System.Drawing.Color]::White
$btnConfirmBack.FlatStyle = 'Flat'
$btnConfirmBack.Add_Click({ 
    $prevStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 4 } else { 3 }
    Show-Step $prevStep $panels['Folder'] 
})
$panels['Confirm'].Controls.Add($btnConfirmBack)
$btnConfirmInstall = New-Object System.Windows.Forms.Button
$btnConfirmInstall.Text = "Install"
$btnConfirmInstall.Location = New-Object System.Drawing.Point(450, 320)
$btnConfirmInstall.Size = New-Object System.Drawing.Size(100,36)
$btnConfirmInstall.BackColor = $mainColor
$btnConfirmInstall.ForeColor = [System.Drawing.Color]::White
$btnConfirmInstall.FlatStyle = 'Flat'
$btnConfirmInstall.Add_Click({
    $nextStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 6 } else { 5 }
    Show-Step $nextStep $panels['Progress']
    $form.Refresh()
    
    function Update-Progress($value, $detail) {
        $progressBar.Value = [Math]::Min($value, 100)
        $lblProgDetail.Text = $detail
        $form.Refresh()
        Start-Sleep -Milliseconds 300
    }

    Update-Progress 0 "Preparing for installation..."
    Start-Sleep -Seconds 1

    # 0. .NET 9.0 SDKのインストール
    if ($global:needsDotNetInstall -and $chkInstallDotNet.Checked) {
        Update-Progress 5 "Downloading the .NET 9.0 SDK installer..."
        $dotNetInstaller = Join-Path $PSScriptRoot "dotnet-sdk-9-win-x64.exe"
        try {
            Invoke-WebRequest -Uri "https://aka.ms/dotnet/9.0/windowsdesktop-runtime-win-x64.exe" -OutFile $dotNetInstaller
            Update-Progress 10 "The download of .NET 9.0 SDK has been completed."
            Start-Sleep -Seconds 1
            Update-Progress 15 "Installing .NET 9.0 SDK... (It may take a few minutes to complete)"
            Start-Process -FilePath $dotNetInstaller -ArgumentList "/install /quiet /norestart" -Wait
            Update-Progress 20 "The download of .NET 9.0 SDK has been completed."
        } catch {
            Update-Progress 0 "Failed to install .NET 9.0 SDK."
            return
        }
    }

    Update-Progress 25 "Preparing to copy the source files..."
    Start-Sleep -Seconds 1
    
    # 1. IFoxer/IFoxer/にソースコピー
    $filesSrc = @(
        "BookmarkForm.cs","BookmarkListForm.cs","Form1.cs","Form1.Designer.cs","Form1.resx",
        "IFoxer.csproj","IFoxer.csproj.user","IFoxer.sln","Program.cs","Settings.cs","SettingsForm.cs"
    )
    $src = $PSScriptRoot
    $currentStep = 25
    $stepIncrement = 15 / $filesSrc.Count
    foreach ($f in $filesSrc) {
        Copy-Item -Path (Join-Path $src $f) -Destination $global:projDir -Force -ErrorAction Stop
        $currentStep += $stepIncrement
        Update-Progress $currentStep "Copying: $f"
        Start-Sleep -Milliseconds 500
    }
    Update-Progress 40 "The copy of the source file is complete."
    Start-Sleep -Seconds 1
    
    # 2. ビルド
    Update-Progress 45 "Preparing to build the application..."
    Start-Sleep -Seconds 1
    Update-Progress 50 "Running the build... Please wait a moment."
    $buildResult = & dotnet build (Join-Path $global:projDir "IFoxer.csproj") -c Debug
    if ($LASTEXITCODE -ne 0) {
        Update-Progress 45 "Build failed. Please check the log."
        return
    }
    Update-Progress 70 "The build has completed successfully."
    Start-Sleep -Seconds 1

    # 3. bin/Debug/net9.0-windows/にリソース・成果物コピー
    Update-Progress 75 "Preparing to copy the deliverable file..."
    $binSrc = Join-Path $global:projDir "bin/Debug/net9.0-windows"
    $binDst = $global:binDir
    # net9.0-windows フォルダ全体をコピー
    Copy-Item -Path $binSrc\* -Destination $binDst -Recurse -Force -ErrorAction Stop
    # index.html と IFoxer-Photoroom.png を追加コピー
    Copy-Item -Path (Join-Path $src "index.html") -Destination $binDst -Force -ErrorAction Stop
    Copy-Item -Path (Join-Path $src "IFoxer-Photoroom.png") -Destination $binDst -Force -ErrorAction Stop
    Update-Progress 90 "The copy of the deliverable file has been completed."
    Start-Sleep -Seconds 1

    # WebView2
    if ($global:needsWebView2Install -and $chkInstallWebView2.Checked) {
        Update-Progress 92 "Preparing the WebView2 runtime..."
        $wv2Installer = Join-Path $PSScriptRoot "MicrosoftEdgeWebView2Setup.exe"
        try {
            if (!(Test-Path $wv2Installer)) {
                Invoke-WebRequest -Uri "https://go.microsoft.com/fwlink/p/?LinkId=2124703" -OutFile $wv2Installer
            }
            Update-Progress 95 "Installing WebView2 runtime..."
            Start-Process -FilePath $wv2Installer -ArgumentList "/silent /install" -Wait
        } catch {
            Update-Progress 90 "Failed to install the WebView2 runtime."
            Start-Sleep -Seconds 2
        }
    }
    
    Update-Progress 100 "Final processing..."
    Start-Sleep -Seconds 2
    Update-Progress 100 "Installation complete!"
    Start-Sleep -Milliseconds 500
    $finalStep = if ($global:needsDotNetInstall -or $global:needsWebView2Install) { 7 } else { 6 }
    Show-Step $finalStep $panels['Finish']
})
$panels['Confirm'].Controls.Add($btnConfirmInstall)

# --- Progress ---
$lblProg = New-Object System.Windows.Forms.Label
$lblProg.Text = "Installing..."
$lblProg.Font = $fontTitle
$lblProg.Location = New-Object System.Drawing.Point(40, 60)
$lblProg.Size = New-Object System.Drawing.Size(500, 40)
$panels['Progress'].Controls.Add($lblProg)
$progressBar = New-Object System.Windows.Forms.ProgressBar
$progressBar.Location = New-Object System.Drawing.Point(40, 120)
$progressBar.Size = New-Object System.Drawing.Size(500, 28)
$progressBar.Minimum = 0
$progressBar.Maximum = 100
$panels['Progress'].Controls.Add($progressBar)
$lblProgDetail = New-Object System.Windows.Forms.Label
$lblProgDetail.Text = ""
$lblProgDetail.Location = New-Object System.Drawing.Point(40, 170)
$lblProgDetail.Size = New-Object System.Drawing.Size(500, 30)
$panels['Progress'].Controls.Add($lblProgDetail)

# --- Finish ---
$lblFinish = New-Object System.Windows.Forms.Label
$lblFinish.Text = "The installation is complete!"
$lblFinish.Font = $fontTitle
$lblFinish.Location = New-Object System.Drawing.Point(40, 60)
$lblFinish.Size = New-Object System.Drawing.Size(500, 40)
$panels['Finish'].Controls.Add($lblFinish)

$chkDeleteInstaller = New-Object System.Windows.Forms.CheckBox
$chkDeleteInstaller.Text = "Do you want to delete the installer folder (this folder)?"
$chkDeleteInstaller.Location = New-Object System.Drawing.Point(40, 120)
$chkDeleteInstaller.Size = New-Object System.Drawing.Size(400, 30)
$chkDeleteInstaller.Checked = $true
$panels['Finish'].Controls.Add($chkDeleteInstaller)

$btnFinishClose = New-Object System.Windows.Forms.Button
$btnFinishClose.Text = "Close"
$btnFinishClose.Location = New-Object System.Drawing.Point(450, 320)
$btnFinishClose.Size = New-Object System.Drawing.Size(100,36)
$btnFinishClose.BackColor = $mainColor
$btnFinishClose.ForeColor = [System.Drawing.Color]::White
$btnFinishClose.FlatStyle = 'Flat'
$btnFinishClose.Add_Click({
    if ($chkDeleteInstaller.Checked) {
        try {
            Remove-Item -Path $PSScriptRoot -Recurse -Force
        } catch {
            [System.Windows.Forms.MessageBox]::Show("Failed to delete the installer folder. Please delete it manually.", "Deletion failed", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
        }
    }
    $form.Close()
})
$panels['Finish'].Controls.Add($btnFinishClose)

# --- 最初の画面を表示 ---
Show-Step 1 $panels['Welcome']
$form.ShowDialog()